"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var context = new window.AudioContext();

var rhythm = {
  patterns: [{
    sound: "hat",
    beats: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0]
  }, {
    sound: "snare",
    beats: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0]
  }, {
    sound: "kick",
    beats: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0]
  }]
};
var cursor = 0;
var tempo = 128;
var rhythmLength = rhythm.patterns[0].beats.length;
var ee = require('event-emitter');
var emitter = ee({});

window.buffers = {};
loadBuffer("drum/snare.wav").then(function (buffer) {
  window.buffers["snare"] = buffer;
});
loadBuffer("drum/kick.wav").then(function (buffer) {
  window.buffers["kick"] = buffer;
});
loadBuffer("drum/hat.wav").then(function (buffer) {
  window.buffers["hat"] = buffer;
});
function getBuffer(name) {
  return window.buffers[name];
}
function loadBuffer(url) {
  var context = new window.OfflineAudioContext(2, 1, 44100);
  return new Promise(function (resolve, reject) {
    var request = new window.XMLHttpRequest();
    request.open('GET', url, true);
    request.responseType = 'arraybuffer';
    request.onload = function () {
      context.decodeAudioData(request.response, resolve, reject);
    };
    request.onerror = reject;
    request.send();
  });
};

var startedPlaying;
var lastTick;
var cursorAtPlay;
var cursor;
var playing;
function _play() {
  startedPlaying = context.currentTime;
  lastTick = context.currentTime - cursor % 1 * getTickLength();
  cursorAtPlay = cursor;
  startPlayback();
}

function getTickLength() {
  return 60 / tempo / 4;
}

function startPlayback() {
  renderPattern().then(playLoop).then(function () {
    playing = true;
  });
}

var playbackSource;
function stopPlayback() {
  playbackSource.stop(context.currentTime);
}

function playLoop(loopBuffer) {
  var source = context.createBufferSource();
  source.buffer = loopBuffer;
  source.connect(context.destination);
  source.loop = true;
  source.start(context.currentTime, cursor * getTickLength());
  if (playbackSource) {
    playbackSource.stop(context.currentTime);
  }
  playbackSource = source;
}

function renderPattern() {
  var startTime = context.currentTime;
  return new Promise(function (resolve, reject) {
    var tickLength = getTickLength();
    var context = new window.OfflineAudioContext(1, rhythmLength * tickLength * 44100, 44100);
    rhythm.patterns.forEach(function (pattern) {
      var buffer = getBuffer(pattern.sound);
      pattern.beats.forEach(function (beat, i) {
        if (beat > 0) {
          var source = context.createBufferSource();
          source.buffer = buffer;
          source.connect(context.destination);
          var when = i * tickLength;
          source.start(when);
        }
      });
    });
    context.startRendering();
    context.oncomplete = function (e) {
      resolve(e.renderedBuffer);
    };
  });
}

function _pause() {
  if (!playing) {
    return;
  }
  stopPlayback();
  updateCursor();
  playing = false;
}

function updateCursor() {
  var playedTime = context.currentTime - startedPlaying;
  var playedTicks = playedTime / getTickLength();
  cursor = (cursorAtPlay + playedTicks) % rhythmLength;
}

function _stop() {
  _pause();
  cursor = 0;
}

function update() {
  if (playing) {
    var tickLength = getTickLength();
    while (context.currentTime > lastTick + tickLength) {
      lastTick = lastTick + tickLength;
      cursor++;
      cursor = cursor % rhythmLength;
      emitter.emit('change');
    }
  }
  window.requestAnimationFrame(update);
}
update();

exports["default"] = {
  play: function play() {
    _play();
  },
  pause: function pause() {
    _pause();
  },
  stop: function stop() {
    _stop();
  },
  getCursor: function getCursor() {
    return cursor;
  },
  getTempo: function getTempo() {
    return tempo;
  },
  setTempo: function setTempo(newTempo) {
    tempo = newTempo;
    emitter.emit('change');
  },
  getRhythm: function getRhythm() {
    return rhythm;
  },
  changeRhythm: function changeRhythm(soundIndex, beatIndex, newVal) {
    rhythm.patterns[soundIndex].beats[beatIndex] = newVal;
    emitter.emit('change');
  },
  emitter: emitter
};
module.exports = exports["default"];
//# sourceMappingURL=machine.js.map