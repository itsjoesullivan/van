var greet = function () {
    return 'Hello Universe!'
};

export default greet;

//# sourceMappingURL=../hello_world/hello_universe.js.map