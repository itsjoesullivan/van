// Auto-update logic
"use strict";

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = require("react");

var _react2 = _interopRequireDefault(_react);

var _machine = require("./machine");

var _machine2 = _interopRequireDefault(_machine);

require('./lib/update');

window.machine = _machine2["default"];

var App = _react2["default"].createClass({
  displayName: "App",

  getInitialState: function getInitialState() {
    return getState();
  },
  render: function render() {
    var state = this.state;
    return _react2["default"].createElement(
      "div",
      null,
      _react2["default"].createElement(
        "div",
        null,
        this.state.rhythm.patterns.map((function (pattern, i) {
          return _react2["default"].createElement(
            "div",
            null,
            _react2["default"].createElement(
              "label",
              null,
              pattern.sound
            ),
            pattern.beats.map((function (beat, j) {
              var spanClass = Math.floor(state.cursor) === j ? "cursor" : "";
              var beatClass = beat > 0 ? "beat" : "";
              var checkbox;
              var handler = this.rhythmChange.bind(this, i, j, beat > 0 ? 0 : 1);
              if (beat > 0) {
                checkbox = _react2["default"].createElement("input", { type: "checkbox", checked: true });
              } else {
                checkbox = _react2["default"].createElement("input", { type: "checkbox" });
              }
              return _react2["default"].createElement(
                "span",
                { className: spanClass, onClick: handler },
                checkbox
              );
            }).bind(this))
          );
        }).bind(this))
      ),
      _react2["default"].createElement("input", { type: "number", value: this.state.tempo, onChange: this.changeTempo }),
      _react2["default"].createElement(
        "button",
        { onClick: _machine2["default"].play },
        "play"
      ),
      _react2["default"].createElement(
        "button",
        { onClick: _machine2["default"].pause },
        "pause"
      )
    );
  },
  changeTempo: function changeTempo(e) {
    _machine2["default"].setTempo(e.currentTarget.value);
  },
  rhythmChange: function rhythmChange(soundIndex, beatIndex, newVal) {
    _machine2["default"].changeRhythm(soundIndex, beatIndex, newVal);
  }
});

var app = _react2["default"].render(_react2["default"].createElement(App, null), document.getElementById("app"));

function getState() {
  return {
    rhythm: _machine2["default"].getRhythm(),
    tempo: _machine2["default"].getTempo(),
    cursor: _machine2["default"].getCursor()
  };
}

_machine2["default"].emitter.on('change', function () {
  app.setState(getState());
});
//# sourceMappingURL=script.js.map